import { TestFeature } from "../features/Hello/Test/TestFeature";

export const Hello = () => {
  return (
    <>
      <h1>Hello</h1>

      <TestFeature />
    </>
  );
};
