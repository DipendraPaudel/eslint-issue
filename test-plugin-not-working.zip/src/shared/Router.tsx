import { TestFeature } from "../features/Hello/Test/TestFeature";

export const Rotuer = () => {
  return (
    <>
      <h1>Shared Router</h1>

      <TestFeature />
    </>
  );
};
